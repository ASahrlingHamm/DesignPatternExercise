public interface MakeGarmentCommand {

     void finishGarment();
}
